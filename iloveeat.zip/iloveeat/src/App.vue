<template>
  <div id="app">
    <Top></Top>
    <Head></Head>
    <Body></Body>
    <Foot></Foot>
  </div>
</template>

<script>
import Head from "@/components/Heard";
import Top from "@/components/Top";
import Foot from "@/components/Foot";
import Body from "@/components/Body";
export default {
  name: "App",
  components: { Head, Top, Foot, Body }
};
</script>

<style></style>
