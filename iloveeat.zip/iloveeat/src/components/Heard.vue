<template>
  <div class="header">
    <div class="container">
      <div class="logo">
        <a href=" ">
          <img src="@/assets/images/logo.png" class="img-responsive" alt />
        </a>
      </div>
      <div class="header-left">
        <div class="head-nav">
          <span class="menu"></span>
          <ul>
            <!-- 判斷現在在哪個網頁 -->

            <li>
              <a href="<%= request.getContextPath() %>/front-end/index.jsp">Home</a>
            </li>
            <!-- 回首頁 -->
            <li>
              <a
                href="<%= request.getContextPath() %>/front-end/restaurants/Restaurants.jsp"
              >Restaurants</a>
            </li>
            <!-- 餐廳 -->
            <li>
              <a
                href="<%= request.getContextPath() %>/front-end/article/SelectArticlePage.jsp"
              >Articles</a>
            </li>
            <!-- 食記 -->
            <li>
              <a href="<%=request.getContextPath() %>/front-end/contact/iEatcontact.jsp">Contact</a>
            </li>
            <!-- 聯絡我們 -->
            <div class="clearfix"></div>
          </ul>
        </div>
        <div class="clearfix"></div>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style></style>
