<template>
  <div>
    <div class="banner"></div>
    <!-- Carousel-->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>

      <!-- Wrapper for slides -->
      <div class="carousel-inner" role="listbox">
        <div v-for="i in 1" :key="i">
          <div class="active">
            <img
              class="ad"
              style="cursor: pointer;"
              src="@/assets/images/logo.png"
              title="${adVO.ad_imagetitle }"
              alt="${adVO.store_no }"
            />
          </div>
        </div>
      </div>

      <!-- Left and right controls -->
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
    <div style="margin:20px">
      <div class="container">
        <div class="col-md-7">
          <div class="news">
            <h3>最新優惠</h3>
            <hr style="border:none;background-color:#5A9522;:red;height:5px;" />
            <ul>
              <div v-for="i in 1" :key="i">
                <li>
                  <span>${disVO.discount_startdate }~${disVO.discount_enddate }</span>
                  <span>
                    <a href>${disVO.discount_title }</a>
                  </span>
                </li>
              </div>
            </ul>
          </div>
          <!--news-->
        </div>
        <div class="col-md-5">
          <!-- SearchBar -->
          <div id="searchBar">
            <form method="post" action="<%= request.getContextPath() %>/store/store.do">
              <div class="input-group">
                <input type="hidden" name="action" value="listStores_ByCompositeQuery" />
                <input
                  type="text"
                  class="form-control"
                  placeholder="Search"
                  name="store_name"
                  value="${param.store_name }"
                />
                <span class="input-group-btn">
                  <button class="btn btn-success" type="submit">
                    <i class="glyphicon glyphicon-search"></i>
                  </button>
                </span>
              </div>
              <br />
              <div class="form-inline">
                <select class="form-control" id="zone1"></select>
                <select class="form-control" id="zone2"></select>
                <input type="hidden" id="store_ads" name="store_ads" value="${param.store_ads }" />
                <input type="hidden" name="store_status" value="1" />
                <select class="form-control" name="store_type_no">
                  <option value>餐廳種類</option>
                  <div v-for="i in 1" :key="i">
                    <option value="${stVO.store_type_no }">${stVO.store_type_name}</option>
                  </div>
                </select>
              </div>
            </form>
          </div>
          <!-- SearchBar -->
        </div>
      </div>
      <!--container-->
    </div>

    <!-- Carousel-->
    <div class="latis">
      <div class="container">
        <div class="col-md-9">
          <div class="index_row">
            <h3>推薦餐點</h3>
            <div v-for="i in 1" :key="i">
              <div class="col-md-4 latis-left">
                <h4>aaaaaaaaaaaa</h4>
                <div style="height:150px;width:100%;overflow:hidden">
                  <img src="@/assets/images/logo.png" class="img-responsive" alt />
                </div>
                <div class="simpleCart_shelfItem">
                  <p style="width:45%;height:25px;overflow:hidden">${mealVO.meal_descr}</p>
                  <div class="cur">
                    <div class="cur-left add_to_cart">
                      <input type="hidden" name="meal_no" value="${mealVO.meal_no}" />
                      <a class="morebtn hvr-rectangle-in" style="cursor: pointer;">加入餐車</a>
                    </div>
                    <div class="cur-right">
                      <h6>價格$${mealVO.meal_price}</h6>

                      <h6>優惠價$ ${mealVO.meal_discount}</h6>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
          </div>
          <!--row-->
          <div class="index_row">
            <h3>食記精選</h3>
            <div v-for="i in 1" :key="i">
              <div class="col-md-5">
                <div id="hot_article">
                  <div style="width:100%;height:200px;overflow:hidden;margin-bottom:10px">
                    <img class="img-responsive" src="@/assets/images/logo.png" />
                  </div>
                  <h4>
                    <a href>${artVO.art_name}</a>
                  </h4>
                  <p
                    style="overflow: hidden;line-height:1.4em;height:8.4em;"
                  >${articleSvc.getContext(artVO.art_no,100)}</p>
                  <a class="see" href>See More</a>
                  <div class="clearfix"></div>
                </div>
              </div>
            </div>
            <div class="col-md-7">
              <div id="articles">
                <div v-for="i in 1" :key="i">
                  <div class="article">
                    <div class="col-md-4">
                      <img class="img-responsive" src />
                    </div>
                    <div class="col-md-8">
                      <h4>
                        <a
                          href="<%=request.getContextPath()%>/article/article.do?action=getFor_Display&art_no=${artVO.art_no}"
                        >${artVO.art_name}</a>
                      </h4>
                      <p
                        style="overflow: hidden;line-height:1.4em;height:4.2em;"
                      >${articleSvc.getContext(artVO.art_no,45)}</p>
                      <a
                        class="see"
                        href="<%=request.getContextPath()%>/article/article.do?action=getFor_Display&art_no=${artVO.art_no}"
                      >See More</a>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
          </div>
        </div>
        <div class="col-md-3">
				<div class="top">			
					<h3>排行榜</h3>
					<div class="top_half">
						<h4>人氣美食TOP5</h4>
						<div class="top_pic">
							<div v-for="i in 1" :key="i">
							
								<a href="<%= request.getContextPath()%>/checkout/Orders.jsp?store_no=${mealSvc.getOneMeal(ord_mealVO.meal_no).store_no }">
									<img src="">
								</a>
						
							</div>
						</div>
						<ul>
							<div v-for="i in 1" :key="i">
								<li><a href="<%= request.getContextPath()%>/checkout/Orders.jsp?store_no=${mealSvc.getOneMeal(ord_mealVO.meal_no).store_no }" id="b${s.count}">${mealSvc.getOneMeal(ord_mealVO.meal_no).meal_name } </a></li>
							</div>
						</ul>
					</div><!--top1-->
					<div class="top_half">
						<h4>人氣餐廳TOP5</h4>
						<div class="top_pic">
							<div v-for="i in 1" :key="i">
							 
									<a href="<%= request.getContextPath()%>/store/store.do?action=getOne_For_Display&store_no=${ordVO.store_no}">
										<img src=" ">
									</a>
							 
							</div>
						</div>
						<ul>
							<div v-for="i in 1" :key="i">
								<li><a href="<%= request.getContextPath()%>/store/store.do?action=getOne_For_Display&store_no=${ordVO.store_no }" id="a${t.count}">${storeSvc.getOneStore(ordVO.store_no).store_name } </a></li>
							</div>
						</ul>
						<a style="float:right" href="<%= request.getContextPath() %>/front-end/restaurants/Restaurants.jsp">more>></a>
					</div><!--top2-->		
				</div>
			</div>
      </div>
    </div>
    <!-- feature -->
    <div class="feature">
      <div class="container">
        <div class="fle-xsel">
          <ul id="flexiselDemo3">
            <li>
              <a href>
                <img
                  style="width: 7em;height: 7em"
                  src="@/assets/images/logo.png"
                  class="img-responsive"
                  title="${mealVO.meal_name }"
                />
                xxxxxxxxx
              </a>
            </li>
          </ul>

          <div class="clearfix"></div>
        </div>
      </div>
    </div>
    <!-- feature -->
  </div>
</template>
<script>
import $ from "jquery";
export default {
  data() {
    return { dadd: "" };
  },
  mounted() {
    this.initJquery();
  },
  methods: {
    initJquery() {
      $("#flexiselDemo3").flexisel({
        visibleItems: 8,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: {
          portrait: {
            changePoint: 480,
            visibleItems: 2
          },
          landscape: {
            changePoint: 640,
            visibleItems: 3
          },
          tablet: {
            changePoint: 768,
            visibleItems: 3
          }
        }
      });
    }
  }
};
</script>
<style>
</style>