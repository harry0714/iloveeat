<template>
  <div class="footer">
    <div class="container">
      <div class="footer-left">
        <p>Copyrights &copy; 2016 iEat All rights reserved</p>
      </div>
      <div class="footer-right">
        <ul>
          <li>
            <a href="#">
              <i class="fbk"></i>
            </a>
          </li>
          <li>
            <a href="#">
              <i class="googpl"></i>
            </a>
          </li>
          <li>
            <a href="#">
              <i class="link"></i>
            </a>
          </li>
          <li>
            <a href="#">
              <i class="rss"></i>
            </a>
          </li>
          <li>
            <a href="#">
              <i class="twt"></i>
            </a>
          </li>
        </ul>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</template>