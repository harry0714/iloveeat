import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router'
import 'bootstrap/dist/css/bootstrap.css'
import '@/assets/css/style.css'
import 'bootstrap' 
import '@/assets/js/jquery.flexisel.js'


Vue.use(VueRouter)
new Vue({
  render: h => h(App),
}).$mount('#app')
